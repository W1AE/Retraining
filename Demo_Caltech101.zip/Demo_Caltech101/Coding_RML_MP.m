%%% This file is to reproduce the results of Table 4
%%% RML-MP on Caltech101 dataset using Inception-v3 feature: Accuracy=91.7

clear all;
AE_1=500;   %The number of neurons in the first AE
AE_2=300;   %The number of neurons in the second AE

%% [1] Reproduce the result in Table 4

C1 = 2;
ACCA_b=My_Demo(C1, AE_1, AE_2, 1);
ACCA_b

%% [2] Grid Search
for ii=1:11
    C1 = 10 .^ [-5 -4 -3 -2 -1 0 1 2 3 4 5];
    ACCA(ii)=My_Demo(C1(ii), AE_1, AE_2, 1);
end
ACCA