function [auc,X,Y] = my_roc_curve(deci,label_y,label_of_positive_samples,type_of_deci)
% % deci is the actual output
% % label_y is the desired output, i.e., the true label. It
% % label_of_positive_samples is the label of the positive_samples
% % type_of_deci is the actual output type, including
% %     1: the probability belonging to positive sample.
% %     2: the distance. The smaller distance, the closer to positive sample.

switch type_of_deci
    case 1
        %
    case 2
        deci = 1 ./ deci;
    otherwise
        error('Unknown switch case.');
end
[X,Y,~,auc] = perfcurve(label_y,deci,label_of_positive_samples);

end

