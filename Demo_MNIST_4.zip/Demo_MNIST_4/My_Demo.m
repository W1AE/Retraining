function ACCA = My_Demo(C, N_sub, N_exsub, batch_num)
%% Dataset

batch_num=1;

load('M_4.mat');

trainingFeatures=[T_train X_train];
testingFeatures=[T_test X_test];

T_train=trainingFeatures(:,1);
T_test=testingFeatures(:,1);
[X_train,X_test]=minmaxfun(trainingFeatures,testingFeatures);
clear trainingFeatures;clear testingFeatures;

numClasses=1;
subnetwork_No=5;
IN=size(X_test,2);
save Training X_train -v7.3;
save Testing X_test -v7.3;
save T_train T_train -v7.3;
save T_test T_test -v7.3;

%% Set_processing

T_processing1(1, 1, 1);

X_train_processing(1);

X_test_processing();

%% Parameters

L_Rate=[1 1 1];

AE_parameters.number_of_hidden_layer_neurons = (N_sub+N_exsub)/2;

relu=2;

droprate=0;

ActivationFunction='no';

number_of_AEs=size(AE_parameters.number_of_hidden_layer_neurons,2);
AE_parameters.C = [1];%ע�⣬���������ز������ʱ�����������û���õ�
AE_parameters.sigmoid_parameter = [1];%0.8%����Ϊ1��ʱ�����?sigmoid����
AE_parameters.activation_function = {'Linear'};%cell����

%% Initialization

[InputWeight, ActivationFunction] = ML_Structure(AE_parameters,number_of_AEs,C,ActivationFunction,batch_num,IN);

%% SNN

[InputWeight1, ACCURACY_SUB, ACCA]=TELM33_new(C,InputWeight,batch_num,number_of_AEs,droprate,relu,L_Rate,subnetwork_No, ActivationFunction, 1);

end